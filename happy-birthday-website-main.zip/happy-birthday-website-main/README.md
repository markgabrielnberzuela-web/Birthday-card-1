# happy-birthday-website
A fun and interactive happy birthday website with animations and confetti
