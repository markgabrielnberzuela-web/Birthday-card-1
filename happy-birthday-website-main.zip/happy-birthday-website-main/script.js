// Get elements
const envelope = document.getElementById('envelope');
const letter = document.getElementById('letter');
const addBtn = document.getElementById('addBtn');
const heartsContainer = document.getElementById('heartsContainer');

let isOpen = false;

// Open/Close envelope on click
envelope.addEventListener('click', function() {
    isOpen = !isOpen;
    
    if (isOpen) {
        envelope.classList.add('open');
        createFloatingHearts();
    } else {
        envelope.classList.remove('open');
        clearHearts();
    }
});

// Create floating hearts
function createFloatingHearts() {
    // Create multiple hearts
    for (let i = 0; i < 15; i++) {
        setTimeout(() => {
            const heart = document.createElement('div');
            heart.classList.add('heart');
            heart.textContent = '💗';
            
            // Random horizontal position
            const randomX = Math.random() * 300 - 150;
            heart.style.setProperty('--tx', randomX + 'px');
            
            // Random left position
            const randomLeft = Math.random() * 350 + 25;
            heart.style.left = randomLeft + 'px';
            
            // Random bottom start position
            const randomBottom = Math.random() * 50 + 80;
            heart.style.bottom = randomBottom + 'px';
            
            // Random animation duration
            const randomDuration = Math.random() * 1 + 2.5;
            heart.style.animationDuration = randomDuration + 's';
            
            // Random delay
            const randomDelay = Math.random() * 0.5;
            heart.style.animationDelay = randomDelay + 's';
            
            heartsContainer.appendChild(heart);
            
            // Remove heart after animation completes
            setTimeout(() => {
                heart.remove();
            }, (randomDuration + randomDelay) * 1000);
        }, i * 100);
    }
}

// Clear all hearts
function clearHearts() {
    const hearts = document.querySelectorAll('.heart');
    hearts.forEach(heart => heart.remove());
}

// Add button functionality
addBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    
    // Create event for calendar/reminder
    const eventTitle = "Happy Birthday Arsyl";
    const eventDate = new Date();
    eventDate.setHours(0, 0, 0, 0);
    
    // Format date for calendar
    const year = eventDate.getFullYear();
    const month = String(eventDate.getMonth() + 1).padStart(2, '0');
    const day = String(eventDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}${month}${day}`;
    
    // Google Calendar URL
    const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(eventTitle)}&dates=${formattedDate}/${formattedDate}&details=${encodeURIComponent("Happy Birthday to our princess Arsyl!")}&location=&trp=false`;
    
    // Try to open Google Calendar
    window.open(googleCalendarUrl, '_blank');
    
    // Alternative: Show alert if calendar doesn't open
    alert('Opening calendar to add this event!\n\nEvent: ' + eventTitle);
});

// Add visual feedback to button on hover
addBtn.addEventListener('mouseenter', function() {
    this.style.transform = 'scale(1.1)';
});

addBtn.addEventListener('mouseleave', function() {
    this.style.transform = 'scale(1)';
});
